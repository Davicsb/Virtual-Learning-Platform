/**
 * Dados enviados para criar um novo curso (Admin)
 */
export interface CreateCursoRequest {
  title: string;
  description: string;
}